# Student Grade Portal

A Flask web app for calculating student grades from an uploaded Excel workbook.

## Deploy online with Render

1. Create a GitHub repository and upload all files/folders from this project.
2. Open https://dashboard.render.com/ and choose **New + → Web Service**.
3. Connect the GitHub repository.
4. Keep the settings from `render.yaml`, or enter:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
   - **Instance type:** Free (if available)
5. Click **Deploy Web Service**. When the deployment succeeds, Render shows your public `onrender.com` URL.

## Project files

- `app.py` — Flask website
- `student_grade_calculator.py` — grade calculation logic
- `sample_students.xlsx` — demo workbook
- `templates/` — HTML pages
- `static/style.css` — page styling
- `requirements.txt` — Python dependencies
- `render.yaml` — Render deployment settings

## Excel format

Required columns: `RollNo`, `Name`, `English`, `Maths`, `Science`, `Computer`, `Hindi`.
Title rows above the header row are supported.

## Important

Use fictional/demo student data for public demos. Do not upload confidential student records. Results are held in server memory and may disappear when the service restarts.
